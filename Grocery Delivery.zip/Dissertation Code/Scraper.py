from bs4 import BeautifulSoup
import requests
import csv


#URL to be scraped
url_to_scrape = 'https://www.tesco.com/groceries/en-GB/shop/fresh-food/all?page=1&count=48'
#Load html's plain data into a variable
plain_html_text = requests.get(url_to_scrape)
#parse the data
soup = BeautifulSoup(plain_html_text.text, "lxml")

csv_file = open('Tesco.csv', 'w', newline='')

csv_writer = csv.writer(csv_file)
csv_writer.writerow(['Description','Price'])
#Get the name of the class
for name_of in soup.find_all('div',class_='product-tile-wrapper'):
    name =name_of.h3.a.text
    namedo = name.replace(","," ")
    print(namedo)
    # csv_writer.writerow([namedo])

    try:
        price = name_of.find('div', class_='price-details--wrapper')
        pricen =price.find('span', class_='value').text
        print(pricen)
        csv_writer.writerow([namedo, pricen])
    except:
        soldout = 'Sold out'
        print(soldout)
        csv_writer.writerow([namedo, soldout])

csv_file.close()
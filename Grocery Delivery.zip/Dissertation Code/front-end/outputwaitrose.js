$(document).ready(function(){
 $('#load_waitrose').click(function(){
  $.ajax({
   url:"Waitrose.csv",
   dataType:"text",
   success:function(data)
   {
    var tesco_data = data.split(/\r?\n|\r/);
    var table_data = '<table class="table table-bordered table-striped">';
    for(var count = 0; count<tesco_data.length; count++) {
        var _cellData = tesco_data[count]; 
        var cell_data = _cellData.split(",");
        table_data += '<tr>';
        for(let cell_count=0; cell_count<cell_data.length; cell_count++) {  
            if(count === 0) {
                table_data += '<th>'+cell_data[cell_count]+'</th>';
            } else {
                table_data += '<div class="12at"><td>'+cell_data[cell_count]+'</td></div>';
            }
        }
        table_data += `<td id="lastrow"><button class="addb" onclick="SaveItem('${_cellData }')">Add</button></td>`;
    }
    table_data += '</table>';
    $('#order_list').html(table_data);
   }
  });
 });
 
});


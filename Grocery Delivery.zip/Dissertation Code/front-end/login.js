         
         function checkLogin() {
             
             if(localStorage.loggedinUsrEmail !== undefined) {
                 
                 var usrObj = JSON.parse(localStorage[localStorage.loggedinUsremail]);
                 
                 document.getElementById("loginPara").innerHTM = usrObj.firstName + " logged in."
                 
             }
         }
         
        function login() {
            
            var email = document.getElementById("emailin").value;
            
            if(localStorage[email] === undefined){
                
                document.getElementById("loginFailure").innerHTML = "Email not recognized" ;
                return;
            }
            
            else{
                var usrObj = JSON.parse(localStorage[email]);
                var password = document.getElementById("passwordin").value;
                
                if(password === usrObj.passwrd) {
                    document.getElement
                    document.getElementById("loginFailure").innerHTML = "";
                    localStorage.loggedinUsrEmail =usrObj.email;
                    window.location ="index.html"

                    
                }
                else{
                    document.getElementById("loginFailure").innerHTML = "Password incorrect.";
                }
                
            }
            
        }
         
     
         

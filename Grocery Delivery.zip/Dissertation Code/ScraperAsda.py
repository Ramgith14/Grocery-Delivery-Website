from bs4 import BeautifulSoup
import requests
import csv

#URL to be scraped
url_to_scrape = 'https://www.waitrose.com/ecom/shop/browse/groceries/food_cupboard'
#Load html's plain data into a variable
plain_html_text = requests.get(url_to_scrape)
#parse the data
soup = BeautifulSoup(plain_html_text.text, "lxml")

csv_file = open('Waitrose.csv', 'w', newline='')

csv_writer = csv.writer(csv_file)
csv_writer.writerow(['Description','Price'])

#Get the name of the class
for name_of in soup.find_all('article',class_='visible-xl-flex visible-lg-flex visible-md-flex visible-sm-flex visible-xs-flex productPod___1NmFb col-xs-12of12 col-sm-4of12 col-md-4of12 col-lg-3of12 col-xl-2of12'):
    name =name_of.h2.span.text
    namedo = name.replace(","," ")
    print(namedo)
    try:
        price = name_of.find('section', class_='trolleyChoices___163lU')
        # pricen =price.find('span', class_='prices___1JkR4').span.text
        pricen = price.div.span.span.text
        pricendo = pricen.replace("£","")
        print(pricendo)
        # print(pricen.replace("�","£"))
        csv_writer.writerow([namedo, pricendo])
    except:
        print('Sold Out')

csv_writer.writerow([namedo, pricendo])
csv_file.close()




